#!/bin/bash
# ============================================================
# OpenFS 一键部署脚本 (源码模式)
# 在目标服务器上编译并安装 OpenFS
#
# 用法: sudo bash install.sh [选项]
#
# 选项:
#   --single-node  单节点部署 (默认)
#   --cluster      集群模式部署
#   --verbose      详细输出, 编译时实时显示 (排查问题用)
#
# 环境变量:
#   OPENFS_INSTALL_DEPS=no   跳过系统依赖安装
#   OPENFS_BUILD_TYPE=Debug  使用 Debug 模式编译
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODE="--single-node"
VERBOSE=false

# 解析参数
while [[ $# -gt 0 ]]; do
    case "$1" in
        --single-node) MODE="--single-node"; shift ;;
        --cluster)     MODE="--cluster"; shift ;;
        --verbose|-v)  VERBOSE=true; shift ;;
        -h|--help)
            echo "用法: sudo bash install.sh [--single-node | --cluster] [--verbose]"
            echo ""
            echo "  --single-node  单节点部署 (默认)"
            echo "  --cluster      集群模式"
            echo "  --verbose      详细输出, 实时显示编译日志"
            echo ""
            echo "  环境变量:"
            echo "    OPENFS_INSTALL_DEPS=no   跳过依赖安装"
            echo "    OPENFS_BUILD_TYPE=Debug  Debug 编译"
            exit 0
            ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

INSTALL_DEPS="${OPENFS_INSTALL_DEPS:-yes}"
BUILD_TYPE="${OPENFS_BUILD_TYPE:-Release}"
NPROC="$(nproc 2>/dev/null || echo 4)"

OPENFS_BIN="/usr/local/bin"
OPENFS_ETC="/etc/openfs"
OPENFS_VAR="/var/lib/openfs"
OPENFS_LOG="/var/log/openfs"
OPENFS_USER="openfs"

echo "============================================"
echo "  OpenFS 一键部署 (源码编译模式)"
echo "  模式: $MODE"
echo "  源码: $SCRIPT_DIR"
echo "============================================"

# ---- 0. 安装编译依赖 ----
echo ""
echo "[0/7] 安装编译依赖..."

if [ "$INSTALL_DEPS" = "yes" ]; then
    if command -v apt &>/dev/null; then
        echo "  检测到 Ubuntu/Debian, 安装依赖..."
        apt update -qq
        apt install -y -qq \
            build-essential cmake ninja-build pkg-config \
            libprotobuf-dev protobuf-compiler \
            libgrpc++-dev libspdlog-dev \
            libgtest-dev libgflags-dev \
            uuid-dev liburing-dev 2>/dev/null || {
            echo "  警告: 部分依赖安装失败, 尝试继续编译..."
        }
    elif command -v dnf &>/dev/null; then
        echo "  检测到 RHEL/Rocky, 安装依赖..."
        dnf install -y \
            gcc-c++ cmake ninja-build pkgconfig \
            protobuf-devel protobuf-compiler \
            grpc-devel spdlog-devel \
            gtest-devel gflags-devel \
            libuuid-devel liburing-devel 2>/dev/null || {
            echo "  警告: 部分依赖安装失败, 尝试继续编译..."
        }
    else
        echo "  未识别的包管理器, 请手动安装编译依赖"
        echo "  需要: cmake, protobuf, grpc, spdlog, gtest"
        echo "  继续..."
    fi
else
    echo "  跳过依赖安装 (OPENFS_INSTALL_DEPS=no)"
fi

# ---- 1. 编译 ----
echo ""
echo "[1/7] 编译 OpenFS ($BUILD_TYPE, ${NPROC} 线程)..."
cd "$SCRIPT_DIR"
mkdir -p build

# cmake 配置
echo "  运行 cmake..."
if $VERBOSE; then
    cmake -B build -DCMAKE_BUILD_TYPE="$BUILD_TYPE" 2>&1 | tee build/cmake_configure.log
    CMAKE_RC=${PIPESTATUS[0]}
else
    cmake -B build -DCMAKE_BUILD_TYPE="$BUILD_TYPE" > build/cmake_configure.log 2>&1
    CMAKE_RC=$?
fi
if [ "$CMAKE_RC" -ne 0 ]; then
    echo "  错误: cmake 配置失败! 详见 build/cmake_configure.log"
    echo ""
    echo "  ---- 最后 30 行错误 ----"
    tail -30 build/cmake_configure.log
    echo "  ------------------------"
    echo ""
    echo "  排查方法:"
    echo "    cat $SCRIPT_DIR/build/cmake_configure.log"
    echo "    常见原因: 缺少开发包 (libprotobuf-dev, libgrpc++-dev, libspdlog-dev 等)"
    exit 1
fi
echo "  cmake 配置成功"

# cmake 编译
echo "  运行编译 (日志: build/cmake_build.log)..."
if $VERBOSE; then
    cmake --build build --config "$BUILD_TYPE" -j"$NPROC" 2>&1 | tee build/cmake_build.log
    BUILD_RC=${PIPESTATUS[0]}
else
    cmake --build build --config "$BUILD_TYPE" -j"$NPROC" > build/cmake_build.log 2>&1
    BUILD_RC=$?
fi
if [ "$BUILD_RC" -ne 0 ]; then
    echo "  错误: 编译失败! 详见 build/cmake_build.log"
    echo ""
    echo "  ---- 编译错误 (最后 50 行) ----"
    tail -50 build/cmake_build.log
    echo "  --------------------------------"
    echo ""
    echo "  排查方法:"
    echo "    cat $SCRIPT_DIR/build/cmake_build.log"
    echo "    仅编译单个目标:  cmake --build build --target meta_node"
    echo "    单线程编译(避免错误刷屏): cmake --build build -j1"
    echo "    重新安装部署:      sudo bash install.sh --verbose"
    exit 1
fi
echo "  编译成功!"

# 可选: 运行单元测试
if [ -f "build/test_types" ]; then
    echo ""
    echo "  运行单元测试..."
    (cd build && ctest --output-on-failure -j"$NPROC" --timeout 30 2>&1 | tail -5) || {
        echo "  警告: 部分测试未通过 (不影响安装)"
    }
fi

# ---- 2. 安装二进制 ----
echo ""
echo "[2/7] 安装二进制..."
for bin in meta_node data_node openfs_cli; do
    if [ -f "build/$bin" ]; then
        cp -v "build/$bin" "$OPENFS_BIN/"
        chmod 755 "$OPENFS_BIN/$bin"
    fi
done

# ---- 3. 安装配置文件 ----
echo ""
echo "[3/7] 安装配置文件..."
mkdir -p "$OPENFS_ETC"

for conf in "$SCRIPT_DIR/configs/"*.example; do
    [ -f "$conf" ] || continue
    name=$(basename "$conf" .example)
    if [ ! -f "$OPENFS_ETC/$name" ]; then
        cp -v "$conf" "$OPENFS_ETC/$name"
    else
        echo "  保留已有 $name"
    fi
done

# 首次安装: 确保配置存在
[ ! -f "$OPENFS_ETC/meta_node.conf" ] && \
    cp "$SCRIPT_DIR/configs/meta_node.conf.example" "$OPENFS_ETC/meta_node.conf" 2>/dev/null || true
[ ! -f "$OPENFS_ETC/data_node.conf" ] && \
    cp "$SCRIPT_DIR/configs/data_node.conf.example" "$OPENFS_ETC/data_node.conf" 2>/dev/null || true

# ---- 4. 创建用户和目录 ----
echo ""
echo "[4/7] 创建 openfs 用户和目录..."
if ! id "$OPENFS_USER" &>/dev/null; then
    useradd -r -s /sbin/nologin -d "$OPENFS_VAR" "$OPENFS_USER"
fi
usermod -aG disk "$OPENFS_USER" 2>/dev/null || true
mkdir -p "$OPENFS_VAR"/{meta,data} "$OPENFS_LOG"
chown -R "$OPENFS_USER:$OPENFS_USER" "$OPENFS_VAR" "$OPENFS_LOG"

# ---- 5. 安装 systemd 服务 ----
echo ""
echo "[5/7] 安装 systemd 服务..."
if [ -d /etc/systemd/system ]; then
    for svc in "$SCRIPT_DIR/configs/"*.service; do
        [ -f "$svc" ] && cp -v "$svc" /etc/systemd/system/
    done
    systemctl daemon-reload
fi

# ---- 6. 内核参数调优 ----
echo ""
echo "[6/7] 内核参数调优..."
if [ -d /etc/security/limits.d ]; then
    cat > /etc/security/limits.d/99-openfs.conf << 'EOF'
openfs soft nofile 655360
openfs hard nofile 655360
root   soft nofile 655360
root   hard nofile 655360
EOF
fi
if [ -d /etc/sysctl.d ]; then
    cat > /etc/sysctl.d/99-openfs.conf << 'EOF'
vm.swappiness=1
net.core.somaxconn=65535
net.ipv4.tcp_max_syn_backlog=65535
net.ipv4.tcp_tw_reuse=1
EOF
    [ -f /proc/sys/kernel/io_uring_disabled ] && \
        echo "kernel.io_uring_disabled=0" >> /etc/sysctl.d/99-openfs.conf
    sysctl --system 2>/dev/null || true
fi
for dev in /sys/block/nvme*; do
    [ -d "$dev" ] && echo "none" > "$dev/queue/scheduler" 2>/dev/null || true
done

# ---- 7. 集群模式配置提示 ----
echo ""
echo "[7/7] 配置检查..."
if [ "$MODE" = "--cluster" ]; then
    LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "YOUR_IP")
    echo "  集群模式! 请修改配置:"
    echo "    $OPENFS_ETC/meta_node.conf  → meta.raft_peers"
    echo "    $OPENFS_ETC/data_node.conf  → data.meta_addr, data.disk_paths"
fi

echo ""
echo "============================================"
echo "  OpenFS 部署完成!"
echo "============================================"
echo ""
echo "  启动: sudo systemctl start openfs-meta openfs-data"
echo "  状态: sudo systemctl status openfs-meta openfs-data"
echo "  日志: sudo journalctl -u openfs-data -f"
echo "  测试: bash $SCRIPT_DIR/scripts/run_benchmark.sh --quick"
echo "  CLI:  openfs_cli --meta localhost:8100 ls /"
